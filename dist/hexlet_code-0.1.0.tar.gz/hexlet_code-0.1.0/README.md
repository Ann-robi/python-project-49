### Hexlet tests and linter status:
[![Actions Status](https://github.com/Ann-robi/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Ann-robi/python-project-49/actions)

### CodeClimate:
[![Maintainability](https://api.codeclimate.com/v1/badges/92e2a4f6f497264ea405/maintainability)](https://codeclimate.com/github/Ann-robi/python-project-49/maintainability)

### Game 1: Is Even?:
[![asciicast](https://asciinema.org/a/Z6WVTrAUHzVnwz380uZ5zrZmU.svg)](https://asciinema.org/a/Z6WVTrAUHzVnwz380uZ5zrZmU)

### Game 2: Calculator:
[![asciicast](https://asciinema.org/a/Egh0CU4NoB9pw6LgloNwf8TTZ.svg)](https://asciinema.org/a/Egh0CU4NoB9pw6LgloNwf8TTZ)

### Game 3: GCD:
[![asciicast](https://asciinema.org/a/FgtJRdTD8smJgknL6wQlTWl3Q.svg)](https://asciinema.org/a/FgtJRdTD8smJgknL6wQlTWl3Q)